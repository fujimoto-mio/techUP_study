<?php
$a=7;
$b=2;

$kasan=$a+$b;
$genzan=$a-$b;
$josan=$a*$b;
$jozan=$a/$b;

echo "加算結果:",$kasan,"<br>";
echo "減算結果:",$genzan,"<br>";
echo "乗算結果:",$josan,"<br>";
echo "除算結果:",$jozan,"<br>";
?>